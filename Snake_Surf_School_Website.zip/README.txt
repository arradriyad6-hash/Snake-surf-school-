# Snake Surf School Website

A responsive one-page website for Snake Surf School.

## Files
- index.html — website structure and copy
- styles.css — visual design and responsive layout
- script.js — small interactive behavior
- assets/ — supplied photos

## How to use
Open `index.html` in a browser to preview it.
To publish it, upload the whole folder to a static hosting service.

## Important
The site intentionally does not invent lesson prices. Add your real prices, availability, Instagram link, and any certifications before publishing.
